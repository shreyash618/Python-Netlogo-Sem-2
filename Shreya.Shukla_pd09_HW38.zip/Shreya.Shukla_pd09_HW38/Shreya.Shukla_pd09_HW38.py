# Shreya Shukla
# Intro CS2 pd09
# HW 38: EndOfFiles
# 2019--08--05

# inputs a filename
filename = input('Enter a filename: ') # Enter'Integers_List.txt'
# reads the file
filein = open(filename, 'r')
text = filein.readlines()
# processes the text (removes newline characters and converts each
# string-number to a integer)
text = list(map (lambda x: x.strip('\n'), text))
text = list (map(lambda x: int(x), text))
# creates a empty list, NumberList
NumberList = []
# proccesses each item of the list, text, and moves it to NumberList in smallest
# to greatest integer order
for i in range(len(text)+1):
   if len(text) != 0:
       NumberList.append (min(text))
   text = list (filter(lambda x: x!= min(text), text))
# converts each integer to a string in the NumberList
NumberList = list (map(lambda x: str(x), NumberList))
# joins each item of the NumberList with a newline character, stores this
# as output and prints the output
Output = '\n'.join (NumberList)
print(Output)
# closes the file
filein.close

