# Shreya Shukla
# Intro CS2 pd 09
# HW 34: BeginOfFilesRevisted
# 2019--05--02

filein = open ('Tom_Sawyer_Preface.txt', 'r')
text = str(filein.read())

# count lines
numLines = 0
for i in text:
    if i == '\n':
        numLines += 1
print ('Lines:', numLines)

# count words
numWords = 0
for i in (text.strip ('\n')).split (' '):
    numWords += 1
    if '\n' in i:
        numWords += 1

print ('Words: ',numWords)

# count characters
numChar = 0
for i in text:
    numChar += 1
print ('Characters: ',numChar)
filein.close

#lines-22     words-160     characters-906

