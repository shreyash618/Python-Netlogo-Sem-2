# Shreya Shukla
# Intro CS2 pd 09
# HW37: AhKnowIKnowWhereMiddleOfFiles
# 2019--05--05

##PART 1
# asks user for a filename, and reads that file
# asks user for a word, and prints the number of times that word appears in the file

def numOccurences ():
    '''Asks user for a filename and a word.
Returns the number of times that word occurs in the file.'''
    filename = input ('Enter a filename: ')
    filein = open (filename, 'r')
    text = filein.read ()
    word = input('Enter a word: ')
    Recurrences = len(text.split (' '+ word+ ' ')) -1
    print (Recurrences)
    filein.close()

#numOccurences ()

##PART 2:
def newFileWithoutBlanks ():
    '''Asks user to input a filename.
Creates a new revised file without any blank spaces.'''
    
    filename = input ('Enter a filename: ')
    filein = open (filename, 'r')
    text = filein.read ()
    newfile = open ('output.txt', 'w')
    newfile.write(text.replace (' ', ''))
    newfile.close()
    filein.close()

newFileWithoutBlanks()

#Note to MS.K- Should we also replace newlines? If so, then the code would be:
    #newfile.write((text.replace (' ', '')).replace('\n', ''))
