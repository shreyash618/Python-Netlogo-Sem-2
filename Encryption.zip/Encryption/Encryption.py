# Shreya Shukla, Saadat Rafin
# IntroCS2 pd09
# 2019--04--04
# Lab 3: Caesar Encryption

# imports caesar and runs all the files on caesar
import Caesar as c

print ('hello\n')

inp = input ('enter a LETTER you want to encrypt using caeser cipher scheme: ').lower()
print ('encrypting...')
print (c.EncryptOne (inp),'\n')

inp2 = input ('enter a WORD you want to encrypt using caeser cipher scheme: ').lower()
print ('encrypting...')
print (c.EncryptWord (inp2),'\n')

inp3 = input ('enter a LETTER you want to decrypt using caeser cipher scheme: ').lower()
print ('decrypting...')
print (c.DecryptOne (inp3),'\n')

inp4 = input ('enter a WORD you want to decrypt using caeser cipher scheme: ').lower()
print ('decrypting...')
print (c.DecryptWord (inp4),'\n')

inp5 = input ('enter a WORD you want to encrypt using rotation 13 scheme: ').lower()
print ('encrypting...')
print (c.ROT13 (inp5),'\n')

inp6 = input ('enter a WORD you want to decrypt using caeser cipher scheme: ').lower()
print ('decrypting...')
print (c.threeOneTOR (inp6),'\n')
