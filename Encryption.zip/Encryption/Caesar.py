# Shreya Shukla, Saadat Rafin
# IntroCS2 pd09
# 2019--04--04
# Lab 3: Caesar Encryption

#letters is a global variable for all the letters in the alphabet
letters = 'abcdefghijklmnopqrstuvwxyz'

#input values to test the find function
#char = input ('enter a letter: ').lower ()
#word = input ('enter a word: ').lower ()

#if a character is in a word, it finds what index, if not then returns -1
def find (char, word):
    '''Takes in a character, char, and a word, word.
Returns the index position of that character in the word (if char is not in word, returns -1)'''
    if char.lower() in word.lower():
        counter = 0
        for i in word.lower():
            if char.lower() == i:
                break
            counter += 1
    else:
       counter = -1
    return counter
#print (find (char, word))

#tests each letter of the alphabet in stuyvesant
def testFind ():
    '''Tests the find function for each letter from the alphabet in the word, stuyvesant.
Returns the index of the letter in stuyvesant.'''
    for i in letters:
        print ("find " + i + " in " + "stuyvesant ", end = ' ')
        print (find (i, 'stuyvesant'), end = '\n')
#testFind ()

#encrypts a letter, shifts it a specific amount of values in the alphabet
def EncryptOne (L, shift = 3):
    '''Takes in a letter, L and defaults the alphabet shift to 3.
Encrypts the letter by returning the letter 3 after the original in the alphabet, unless otherwise specified.'''
    for i in range (len (letters)):
        if letters[i] == L.lower():
            if i < (26 - shift):
                return letters [i + shift]
            else:
                return letters [i - 26 + shift]
            break

#tests the effects of EncryptOne on each letter of the alphabet

def testEncryptOne ():
    '''Tests EncryptOne by calling it for every letter in the alphabet.
For each letter, it returns the letter three places after the orginal letter.'''
    for i in letters:
        print (EncryptOne (i))
#testEncryptOne ()

#uses EncryptOne for each letter of a word and encrypts the word
def EncryptWord (WORD):
    '''Inputs a word, WORD.
Encrypts the word by replacing each letter with the letter 3 after in the alphabet.'''
    code = ''
    for i in WORD.lower():
       code += EncryptOne (i)
    return code
#print (EncryptWord ('meow')) #should return phrz
#print (EncryptWord ('kitten')) #should return nlwwhq
#print (EncryptWord ('ewwwdog')) #should return hzzzgrj

#takes an encrypted letter and decrypts it to its original place in alphabet
def DecryptOne (L, shift = 3):
    '''Takes in a letter, L and defaults the alphabet shift to 3.
Decrypts the letter by returning the letter 3 before the inputted letter in the alphabet, unless otherwise specified.'''
    for i in range (len (letters)):
        if letters[i] == L.lower():
            if i > (shift - 1):
                return letters [i - shift]
            else:
                return letters [26 -shift + i]
            break

#tests the DecryptOne on each letter of the alphabet
def testDecryptOne ():
    '''Tests DecryptOne by calling it for every letter in the alphabet.
For each letter, it returns the letter three places before the orginal letter.'''
    for i in letters:
        print (DecryptOne (i))
#testDecryptOne ()

#uses DecryptOne to decrypt a word letter by letter
def DecryptWord (WORD):
    '''Inputs a word, WORD.
Decrypts the word by replacing each letter with the letter 3 places before in the alphabet.'''
    code = ''
    for i in WORD.lower():
       code += DecryptOne (i)
    return code
#print (EncryptWord ('phrz')) #should return meow
#print (EncryptWord ('nlwwhq')) #should return kitten
#print (EncryptWord ('hzzzgrj')) #should return ewwwdog

#is the same as EncryptOne but uses a alphabet shift of 13 letters       
def ROT13 (WORD):
    '''Inputs a word, WORD.
Encrypts the word by replacing each letter with the letter 13 places after in the alphabet.'''
    code = ''
    for i in WORD.lower():
       code += EncryptOne (i, 13)
    return code
#print (ROT13 ('dog')) #should return qbt
#print (ROT13 ('cat')) #should return png
#print (ROT13 ('moon')) #should return zbba

#decrypts the words with a shift of 13
def threeOneTOR (WORD):
    '''Inputs a word, WORD.
Decrypts the word by replacing each letter with the letter 13 places before in the alphabet.'''
    code = ''
    for i in WORD.lower():
       code += DecryptOne(i, 13)
    return code
#print (threeOneTOR ('qbt')) #should return dog
#print (threeOneTOR ('png')) #should return cat
#print (threeOneTOR ('zbba')) #should return moon
