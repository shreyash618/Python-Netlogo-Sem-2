#!/usr/bin/python3
import cgi
#permutations function

def perm(wordlist, start, end, perms = []):
    # prints each permutation when all but the last letter has been fixed
    if start == end: 
        perms.append (''.join(wordlist))
    else: 
        for i in range(start, end + 1):
            #swaps indexes of the string
            wordlist[start], wordlist[i] = wordlist[i], wordlist[start]
            #finds permutations of the altered string
            perm(wordlist, start + 1,end, perms)
            #re swaps indexes of the string
            wordlist[start], wordlist[i] = wordlist[i], wordlist[start]
    return perms


def anagram_finder (perms):
    words = []
    anagrams = set() # I used a set here, instead of a list, cause sets have unique items
    #meaning no anagrams would be repeated
    filein = open ('american-english.txt', 'r', encoding = 'utf-8')
    line = filein.readline ()
    while line:
        line = filein.readline()
        words.append (line.lower())
    for perm in perms:
        if (perm.lower() + '\n') in words:
            anagrams.add (perm.lower()) # this method is like append for lists,
            # except it only adds a value if the value isn't already in the set
    filein.close()
    return (anagrams)

def htmlTop():
    print ('''Content-type:text/html\n\n
    <!DOCTYPE html>
    <html lang="en-US">
        <head>
            <meta charset="utf-8" >
            <title>My first server-side script. </title>
        </head>
        <body bgcolor="RosyBrown">''')


def htmlTail():
    print ('''</body>
        </html>''')

def getData():
    formdata = cgi.FieldStorage()
    Word = formdata.getvalue("Word")
    return Word
    
def main():
    htmlTop()
    wordlist = (list(getData()))
    start, end = 0, len(wordlist)- 1
    perms = perm (wordlist, start, end)
    anagrams = anagram_finder (perms)

    print ('Your permutations are:')
    print (perms, end = '\n')
    print ('Your anagrams are:')
    print (anagrams)
    htmlTail()

if __name__ == '__main__':
    try:
        main()
    except:
        cgi.print_exception()
