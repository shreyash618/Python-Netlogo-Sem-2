#!/usr/bin/python3

import cgi
text = "Dear {title} {name},\n\tIt is our pleasure to inform you that you have been selected for this year's {tvshow} participants. Unfortunately,we will not be paying for your travel costs nor your endorsement on tv so we suggest that you save up on funds or get a patron immediately. Sincerely, Management and PR"

def letterEdit (Title, Name, TV):
    return (text.format(title = Title, name= Name, tvshow = TV))


def htmlTop():
    print ('''Content-type:text/html\n\n
    <!DOCTYPE html>
    <html lang="en-US">
        <head>
            <meta charset="utf-8" >
            <title>My first server-side script. </title>
        </head>
        <body bgcolor="darkseagreen">''')

def htmlTail():
    print ('''</body>
        </html>''')

def getdata():
    formdata = cgi.FieldStorage()
    title = formdata.getvalue ("title")
    lastN = formdata.getvalue("lastname")
    TV = formdata.getvalue("TV")
    return title, lastN, TV
    
def main():
    htmlTop()
    title, lastN, TV = getdata ()
    print (letterEdit (title, lastN, TV))
    htmlTail()


if __name__ == '__main__':
    try:
        main()
    except:
        cgi.print_exception()
