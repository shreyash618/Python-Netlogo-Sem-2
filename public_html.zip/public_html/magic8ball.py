#!/usr/bin/python3
import cgi
import random
formdata = cgi.FieldStorage()

Results = ['It is certain.','It is decidedly so.','Without a doubt.', 'Yes, definitely.',
           'You can rely on it.', 'I suppose I see it, yes.', 'Most likely.', 'Outlook good.', 'Yes.'
           , 'Signs point to yes.', 'Reply hazy, try again.', 'Ask again later.', 'Better not tell you now.', "My head hurts, I'll answer later."
           , 'Cannot predict now.', 'Concentrate and ask again.', "Don't count on it.", 'My reply is no.', 'My sources say no.'
           , 'Outlook not so good.', 'Very doubtful.','HELL NO!', "I can't answer that.", "What do you think?", "Follow your heart.",
           "You shouldn't.","You REALLY shouldn't be asking me this.", "Try again later."]

def magic8ball ():
    return (random.choice(Results))

def htmlTop():
    print ('''Content-type:text/html\n\n
    <!DOCTYPE html>
    <html lang="en-US">
        <head>
            <meta charset="utf-8" >
            <title>My first server-side script. </title>
        </head>
        <body bgcolor="Snow">''')


def htmlTail():
    print ('''</body>
        </html>''')
    
def main():
    htmlTop()
    print(magic8ball())
    htmlTail()
    
if __name__ == '__main__':
    try:
        main()
    except:
        cgi.print_exception()


