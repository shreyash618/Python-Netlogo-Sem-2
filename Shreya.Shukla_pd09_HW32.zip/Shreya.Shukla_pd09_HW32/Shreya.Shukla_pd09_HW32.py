# Shreya Shukla
# Intro CS2 pd09
# HW 32: Begin of Files
# 2019-05-03

# asks the user for a filename
Filename = input ('Enter A File Name: ')

# creates a list with 2 parts of a filename: the name of the file, and the type
NameList = Filename.split ('.')

# opens the file, reads it, and stores its text as the variable text
Filein = open (Filename, 'r')
text = Filein.read()

# creates a new copy file if it does not exist, writes upper case text into the new file
NewFile = open(NameList[0] + 'COPY.' + NameList[1], 'w')
NewFile.write (text.upper())

# closes both the original file and the copy
NewFile.close()
Filein.close()

# Note to Ms.K: Please delete the copy files if you want to test my script.
# I have 3 plaintext files and they already have copies in the homework folder.
