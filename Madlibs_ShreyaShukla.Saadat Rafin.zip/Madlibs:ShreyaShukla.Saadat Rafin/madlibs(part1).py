## Team Incredible Student Loans
## Saadat Rafin, Shreya Shukla
## Intro CS2 pd 09
## 2019--05--10
## Modification Lab: Part 1- The Jungle

## PART 1: Inputs user inputs into Jungle.txt
def main():
    '''Reads jungle.txt and edits it using user inputs'''
    # opens a file, reads its contents, and closes the file
    filein = open ('Jungle.txt', 'r')
    text = filein.read()
    filein.close()
    # asks the user for 3 user inputs
    inp1 = input('Enter an animal >> ')
    inp2 = input('Enter a food >> ')
    inp3 = input('Enter a city >> ')
    # creates a new file, JungleMadlibs.txt, and writes the edited version of
    # Jungle.txt into it (using user inputs)
    filein = open('JungleMadlibs.txt','w')
    newtext = text.format(animal = inp1,food = inp2,city = inp3)
    filein.write(newtext)
    # closes the newfile
    filein.close()
main ()
