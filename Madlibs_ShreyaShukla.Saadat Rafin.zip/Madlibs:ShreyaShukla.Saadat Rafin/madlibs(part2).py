## Team Incredible Student Loans
## Saadat Rafin, Shreya Shukla
## Intro CS2 pd 09
## 2019--05--10
## Modification Lab: Part 2- The Newspaper

## PART 2: Inputs user inputs into newspaper_article.txt
def main():
    # opens the file, 'newspaper_article.txt', read text, and closes the file
    filein = open('newspaper_article.txt','r')
    text = filein.read()
    filein.close()
    # opens a new file, 'newspaperMadLibs.txt' and saves it in the folder
    filein = open ('newspaperMadLibs.txt', 'w')
    # asks the user for different inputs
    adj1, adj2, adj3, adj4 = input('Enter 4 comma-separated adjectives: ').split(',')
    noun1, noun2 = input('Enter 2 comma-seperated nouns: ').split(',')
    verb = input ('Enter the past tense of a verb: ')
    color = input('Enter a color: ')
    animal = input ('Enter an animal: ')
    exclm = input ('Enter an exclamatory phrase: ')
    # writes the edited version of newspaper_article.txt into the file, using
    #.format to modify its text
    newtext = text.format(ADJ1 = adj1,ADJ2 = adj2,ADJ3 = adj3,ADJ4 = adj4,
                          NOUN1 = noun1,NOUN2 = noun2,VERP = verb,
                          COLOR = color,ANIMAL = animal,EXCLAMATION = exclm)
    filein.write(newtext)
    # closes the newly created file
    filein.close()
main ()
