## Team Incredible Student Loans
## Saadat Rafin, Shreya Shukla
## Intro CS2 pd 09
## 2019--05--10
## Modification Lab: Part 3_Creating a MadLib

## PART 3: CREATES OUR OWN MAD LIB
from random import choices
PhysAttrs = ['attractive', 'bald', 'beautiful', 'chubby','dazzling', 'drab', 'elegant','fancy','fit','flabby',
             'glamorous','gorgeous','handsome','long','magnificent','muscular','plain','plump','quaint','scruffy',
             'shapely','short','skinny','stocky','ugly','unkempt','unsightly']
Names = ['Andy', 'Justin', 'Bob', 'Dylan', 'Crystal', 'Mrs.Rose','Cole','Matt','Damon','Elena','Stefan', 'Caroline',
         'Julie','Tyler','Bonnie', 'Rebecca','Jeremy','Mr.Smith', 'Jessica', 'Mrs.Kennedy', 'Mr.President', 'Sarah']
WeirdActions = ['dancing and singing loudly','chasing his dog', 'braiding her dolls hair','looking at the bright sky for stars',
           'sleeping', 'polishing shoes','setting a tea party', 'talking to imaginary friends', 'impersonating Mr.Bean',
           'abusing a puppy', 'ripping toys apart', 'watching my little ponies','jumping up and down']
ModesOfTransportation = ['horse', 'bike', 'vespas', 'motorcycle', 'scooter', 'car', 'van','subway' 'bus', 'airplane',
                         'jetski', 'boat']
Times = ['8:00','12:00', '7:00', '10:00','3:00', '2:00','11:00', '5:00','6:00','4:00','1:00','9:00']
Characteristics = ['aggressive','agreeable','ambitious','brave','calm','delightful','eager','faithful','gentle','happy',
                   'jolly','kind','lively','obedient','polite','proud','thankful','victorious','witty','wonderful',
                   'zealous','angry','bewildered','clumsy','defeated','embarrassed','fierce','grumpy','helpless','itchy',
                   'jealous','lazy','mysterious','nervous','obnoxious','panicky','pitiful','repulsive','scary',
                   'thoughtless','uptight','worried']
Professions = ['carpentar','mortician', 'jiu-jitsu instructor', 'gymnast', 'figure-skater', 'scientist',
               'store-owner', 'baker','vendor', 'teacher', 'zoo-worker', 'engineer', 'firefighter','police officer',
               'army officer', 'doctor', 'nurse','pediatrican', 'surgeon', 'optician', 'gynaecologist', 'counselor',
               'pychiatrist', 'serial-killer', 'vampire', 'werewolf']
Colors = ['ashy','ebony','cerulean','gray','vibrant-green','magenta','flaming-red','azule','pinkish-orange','violet',
          'salmon-green']
Afflictions = ['eat me alive', 'rip me to shreds', 'pummel me to the ground', 'beat me alive', 'become my friend',
               'go for a walk with me', 'party with me', 'fight me','yell at me', 'marry me']
Places = ['observation tower','farmhouse','shop','high-rise building','chicken coop','barracks','church','monastery',
          'town hall','skyscraper','stadium', 'pyramid','prison','ice cream parlour','eiffel tower','court',
          'hardware store','office','factory','harbor','internet cafe','orthodontist','kindergarten','market',
          'massage place','gym','nail salon','butchers shop','school','tanning salon','tax department','supermarket',
          'laundromat','ad agency','sausage stand','dentist','wig store']
Actions = ['buy a teddy-bear','eat donuts', 'buy a wig', 'throw a ball', ' listen to sermons','hang out with friends',
          'buy kitchen appliances','buy a house', 'buy groceries','feed my empty stomach','look better', 'explore',
          'start a food fight', 'quit my job', 'yell at my boss', 'apologize to my boss','call in sick', 'give a interview',
          'find a job', 'work', 'monkey around']
def main ():
    '''Takes random items from lists,inputs into the text from the madlibs file
and creates a new file with the modified text.'''
    adj1 = str(choices(PhysAttrs)).strip("''[]'")
    adj2 = str(choices (PhysAttrs)).strip("''[]'")
    name = str(choices (Names)).strip("''[]'")
    weirdaction = str(choices (WeirdActions)).strip("''[]'")
    mot = str(choices (ModesOfTransportation)).strip("''[]'")
    location = str(choices (Places)).strip("''[]'")
    time = str(choices (Times)).strip("''[]'")
    prof = str(choices(Professions)).strip("''[]'")
    adj3 = str(choices (Characteristics)).strip("''[]'")
    color = str(choices(Colors)).strip("''[]'")
    action = str(choices (Actions)).strip("''[]'")
    aflxn = str(choices(Afflictions)).strip("''[]'")

    filein = open ('Our_Own_Prompt.txt','r')
    text = filein.read()
    filein.close
    newtext = text.format (ADJ1 = adj1, ADJ2 = adj2, NAME = name, WEIRDACTION = weirdaction, TIME = time,
                       MOT = mot, ADJ3 = adj3, PROF = prof, AFFLICTION = aflxn, COLOR = color,
                       LOCATION = location, ACTION = action)
    filein = open ('OUROWNMadlibs.txt', 'w')
    filein.write (newtext)
    filein.close()
    
main ()
    
    
    
    
